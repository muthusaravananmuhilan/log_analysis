package loganalysis;
import java.util.*;
import java.io.*;
import java.sql.Timestamp;

public class log 
{
   public static void main(String args[]) throws IOException
   {
	   String file = "C:\\Users\\mmuthusarava\\Documents\\log.txt";
       BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
       String curLine;
       int flag=0;
       System.out.println("Loglevel"+"\t\t"+"Timestamp"+"\t\t\t\t"+"Classname"+"\t\t\t\t\t\t"+"Message");
       while ((curLine = bufferedReader.readLine()) != null)
       {
    	  if(curLine.charAt(0)=='=' || curLine.charAt(0)==' ')
      	  {
      		  System.out.println(curLine);
      	  }
    	  if(curLine.charAt(0)!='=' && curLine.charAt(0)!=' ' )
    	  {
    		  String[] z=curLine.split(" "); 
    		  System.out.print(z[0].trim()+"\t\t");
    		  Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    	      System.out.print(timestamp+"\t\t");
    		  System.out.print(z[4].trim()+"\t\t");
	    	  for(int j=5;j<z.length;j++)
	    	  {
	    		  System.out.print(z[j].trim()+" ");
	    	  }
	    	  System.out.println("");
    	  }
       }
       bufferedReader.close();
   }
}
